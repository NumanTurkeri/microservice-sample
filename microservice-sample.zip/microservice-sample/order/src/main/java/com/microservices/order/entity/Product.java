package com.microservices.order.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Product implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int productId;
    private int amount;
    private String productName;
    private String productPics;
    @ManyToOne
    @JoinColumn(name = "customerOrderId")
    private CustomerOrder order;

    public Product() {
    }

    public Product(int productId, int amount, String productName, String productPics, CustomerOrder order) {
        this.productId = productId;
        this.amount = amount;
        this.productName = productName;
        this.productPics = productPics;
        this.order = order;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPics() {
        return productPics;
    }

    public void setProductPics(String productPics) {
        this.productPics = productPics;
    }

    public CustomerOrder getOrder() {
        return order;
    }

    public void setOrder(CustomerOrder customerOrder) {
        this.order = customerOrder;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }


}
