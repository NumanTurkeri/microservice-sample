package com.microservices.order.controller;

import com.hazelcast.map.IMap;
import com.microservices.order.entity.CustomerOrder;
import com.microservices.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    OrderService service;
    @GetMapping("/getOrder")
    @ResponseStatus(code = HttpStatus.OK)
    public String feignPost() {
        return service.sendValue();
    }
    @GetMapping("/getOrderCache")
    @ResponseStatus(code = HttpStatus.OK)
    public CustomerOrder getFromCache() {
        return service.getValue();
    }

}
