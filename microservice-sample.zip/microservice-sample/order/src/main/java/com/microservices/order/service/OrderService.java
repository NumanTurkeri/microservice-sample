package com.microservices.order.service;

import com.hazelcast.core.HazelcastInstance;
import com.microservices.order.entity.CustomerOrder;
import com.microservices.order.entity.Product;
import com.microservices.order.mq.Order;
import com.microservices.order.mq.RabbitConfiguration;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class OrderService {
    @Autowired
    RabbitTemplate sender;

    @Autowired
    public Map<String, CustomerOrder> basketMap;
    private final HazelcastInstance hazelcastInstance;

    public OrderService(@Qualifier("hazelcastInstance") HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }

    public void addSession(String key, CustomerOrder order) {
        Map<String, CustomerOrder> basketMap = hazelcastInstance.getMap("basketMap");
        basketMap.put(key, order);
    }

    public CustomerOrder getSession(String key) {
        Map<String, CustomerOrder> basketMap = hazelcastInstance.getMap("basketMap");
        return basketMap.get(key);
    }

    public void deleteSession(String key, CustomerOrder order) {
        Map<String, CustomerOrder> basketMap = hazelcastInstance.getMap("basketMap");
        basketMap.remove(key);
    }

    public String sendValue() {
        List<Product> productList=new ArrayList<>();
        Product product=new Product();
        product.setAmount(1200);
        product.setProductName("Filter Kahve");
        product.setProductPics("https://cdn.akakce.com/jacobs/jacobs-selection-250-gr-z.jpg");
        productList.add(product);
        addSession("9090",new CustomerOrder(12,24,productList,"20,01,1987"));
        sender.convertAndSend(RabbitConfiguration.EXCHANGE, RabbitConfiguration.ROUTING_KEY, new Order(11, "2021-10-12", 3400, 12));
        return "OK";
    }
    public CustomerOrder getValue() {
      return getSession("9090");
    }


}
