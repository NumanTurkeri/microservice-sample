package com.microservices.order.mq;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import org.springframework.stereotype.Component;

import java.io.Serializable;
@Component
@JsonIdentityInfo(generator = ObjectIdGenerators.IntSequenceGenerator.class, property = "@id", scope = Order.class)
public class Order implements Serializable {
    public int customerOrderId;
    public String date;
    public int amount;
    public int customerId;

    public Order() {
    }

    public Order(int customerOrderId, String date, int amount, int customerId) {
        this.customerOrderId = customerOrderId;
        this.date = date;
        this.amount = amount;
        this.customerId = customerId;
    }
}
