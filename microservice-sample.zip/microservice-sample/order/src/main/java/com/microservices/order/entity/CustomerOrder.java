package com.microservices.order.entity;

import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
public class CustomerOrder implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int customerOrderId;
    private int customerId;

    @OneToMany( mappedBy = "order",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<Product> productList;
    private String date;
    public CustomerOrder() {
    }


    public int getOrderId() {
        return customerOrderId;
    }

    public void setOrderId(int customerOrderId) {
        this.customerOrderId = customerOrderId;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public CustomerOrder(int customerOrderId, int customerId, List<Product> productList, String date) {
        this.customerOrderId = customerOrderId;
        this.customerId = customerId;
        this.productList = productList;
        this.date = date;
    }

    public int getCustomerOrderId() {
        return customerOrderId;
    }

    public void setCustomerOrderId(int customerOrderId) {
        this.customerOrderId = customerOrderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
}
