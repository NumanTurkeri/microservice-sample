package com.microservices.basket.resource;

import java.io.Serializable;

public class UserResource implements Serializable {
    public int userId;
    public int ownerId;
}
