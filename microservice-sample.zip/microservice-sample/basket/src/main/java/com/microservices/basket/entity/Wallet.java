package com.microservices.basket.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Wallet implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int walletId;
    private BigDecimal amount;
    @OneToOne
    @JoinColumn(name = "productId")
    private Product product;
    @OneToOne
    @JoinColumn(name = "userId")
    private User user;

}
