package com.microservices.basket.service;

import com.microservices.basket.api.CustomerFeignCallableApi;
import com.microservices.basket.entity.Wallet;
import com.microservices.basket.mapping.WalletMapper;
import com.microservices.basket.repository.Tets;
import com.microservices.basket.repository.WalletRepository;
import com.microservices.basket.resource.Customer;
import com.microservices.basket.resource.WalletResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


@Service
public class WalletService {
    private Logger logger = LoggerFactory.getLogger(WalletService.class);
    @Autowired
    CustomerFeignCallableApi customerFeignCallableApi;
    @Autowired
    WalletRepository repository;
    @Autowired
    WalletMapper mapper;

    public void sellProduct(WalletResource resource) {
        Wallet entity = mapper.toEntity(resource);
        entity = repository.save(entity);
        WalletResource newResource = mapper.toResource(entity);

    }

    public String findWithFeignForGet() {
        return customerFeignCallableApi.findCustomer("12");
    }

    public Customer findWithFeignForPost() {
        return customerFeignCallableApi.find(new Customer(12));
    }

    public String sendPostRequest(String userId) {
        RestTemplate restTemplate = new RestTemplate();
        Customer customer = new Customer();
        customer.customerId = 12;

        String resultPost = restTemplate.postForObject("http://localhost:9011/customer/find", customer, String.class);
        return resultPost;
    }

    public String sendGetRequest(String userId) {
        RestTemplate restTemplate = new RestTemplate();
        Customer customer = new Customer();
        customer.customerId = 12;
        String resultPost = restTemplate.getForObject("http://localhost:9011/customer/findCustomer/" + userId, String.class);
        return resultPost;
    }

    //TODO 0 default 1 dakikkadir dir
    /*
     *  @param  asdlan parcasi adami hasta etme
     *  @return dakika
     *
     * */
    @Scheduled(cron = "0 * * * * *")
    public void scheduletTask() {
        logger.info("Scheduled  tasks");
    }
}
