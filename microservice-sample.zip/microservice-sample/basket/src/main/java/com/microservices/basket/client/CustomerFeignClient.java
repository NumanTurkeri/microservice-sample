package com.microservices.basket.client;

import com.microservices.basket.api.CustomerFeignCallableApi;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "CUSTOMER")
public interface CustomerFeignClient extends CustomerFeignCallableApi {

}
