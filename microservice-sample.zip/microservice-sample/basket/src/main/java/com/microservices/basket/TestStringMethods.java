package com.microservices.basket;

public class TestStringMethods {
    public static void main(String[] args) {
        System.out.println("Resul" + doSome("4", "33", "5"));
    }

    public static String doSome(String left, String center, String right) {
        if (center.contains("3")) {
            return left + "" + right;
        } else if (center.equals("33")) {
            return left;
        } else {
            return left + "" + center + "" + right;
        }
    }
    // equals,contains,lastIndexOf,valueOf,substring
}
