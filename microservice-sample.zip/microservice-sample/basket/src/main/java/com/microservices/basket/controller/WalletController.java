package com.microservices.basket.controller;

import com.microservices.basket.resource.Customer;
import com.microservices.basket.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/wallet")
@RestController
public class WalletController {
    @Autowired
    WalletService service;

    @PostMapping("/sell")
    public String feignTuts() {
        return "Hello World";
    }

    @GetMapping("/resttemplate_get")
    public String restGet() {
        return service.sendGetRequest("12");
    }

    @GetMapping("/resttemplate_post")
    public String restPost() {
        return service.sendPostRequest("12");
    }

    @GetMapping("/feign_post")
    public Customer feignPost() {
        return service.findWithFeignForPost();
    }

    @GetMapping("/feign_get")
    public String feignGet() {
        return service.findWithFeignForGet();
    }

}
