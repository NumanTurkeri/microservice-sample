package com.microservices.basket.mapping;

import com.microservices.basket.entity.User;
import com.microservices.basket.entity.Wallet;
import com.microservices.basket.resource.UserResource;
import com.microservices.basket.resource.WalletResource;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper extends IEntityMapper<UserResource, User> {
    //Describe pergh project entrymapper ,citymapper ,educationMapper
}
