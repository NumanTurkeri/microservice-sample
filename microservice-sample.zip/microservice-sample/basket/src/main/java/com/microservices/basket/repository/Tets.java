package com.microservices.basket.repository;

public class Tets {
    public String userName;
    public String sifre;
}
