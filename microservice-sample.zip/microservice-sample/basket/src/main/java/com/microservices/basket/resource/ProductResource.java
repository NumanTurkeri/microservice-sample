package com.microservices.basket.resource;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProductResource implements Serializable {
    public int productId;
    public String productName;
    public BigDecimal price;
}
