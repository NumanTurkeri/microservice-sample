package com.microservices.basket.resource;

import java.io.Serializable;

public class Customer implements Serializable {
    public String userName;
    public int customerId;

    public Customer() {
    }

    public Customer(int customerId) {
        this.customerId = customerId;
    }
}
