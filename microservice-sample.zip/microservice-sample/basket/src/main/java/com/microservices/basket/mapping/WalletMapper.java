package com.microservices.basket.mapping;

import com.microservices.basket.entity.Wallet;
import com.microservices.basket.resource.WalletResource;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface WalletMapper extends IEntityMapper<WalletResource, Wallet> {
    //Describe pergh project entrymapper ,citymapper ,educationMapper
}
