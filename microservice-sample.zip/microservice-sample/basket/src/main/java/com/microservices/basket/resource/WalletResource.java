package com.microservices.basket.resource;

import java.io.Serializable;
import java.math.BigDecimal;

public class WalletResource implements Serializable {
    public int walletId;
    public BigDecimal amount;
    public ProductResource product;
    public UserResource user;
}
