package com.microservices.basket.repository;

import com.microservices.basket.entity.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WalletRepository extends JpaRepository<Wallet, Integer> {
    public Wallet findByWalletId(int walletId);
}
