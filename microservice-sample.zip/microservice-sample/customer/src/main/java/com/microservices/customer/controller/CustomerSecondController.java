package com.microservices.customer.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/second")
@RestController
public class CustomerSecondController {
    @GetMapping("/test")
    public String test(){
        return "customer second hello world";
    }
}
