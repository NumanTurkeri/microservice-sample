package com.microservices.customer.controller;

import com.microservices.customer.resource.Customer;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/customer")
@RestController
public class CustomerController {

    @GetMapping("/findCustomer/{customerId}")
    public String findCustomer(@PathVariable(name = "customerId") String customerId) {
        return  customerId +"id li kullanicinin adi  Numan ";
    }

    @PostMapping("/find")
    public Customer test(@RequestBody Customer customer) {
        Customer customer1 = new Customer();
        customer1.userName = customer.customerId + " id li kullanicinin adi Numan ";
        return customer1;
    }

}
