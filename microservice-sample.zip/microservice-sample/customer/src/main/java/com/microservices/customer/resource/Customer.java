package com.microservices.customer.resource;

import java.io.Serializable;

public class Customer implements Serializable {
    public String userName;
    public int customerId;
}
