package com.microservices.payment.rabbit_mq;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import static com.microservices.payment.rabbit_mq.RabbitConfiguration.QUEUE;

@Component
public class OrderListener {

    @RabbitListener(queues = QUEUE)
    public void consumeMessageFromQueue(Order orderStatus) {
        System.out.println("Message recieved from queue : " + orderStatus);
    }
}
