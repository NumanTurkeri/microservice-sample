package com.microservices.stock.controller;

import com.microservices.stock.resource.ProductResource;
import com.microservices.stock.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    ProductService service;

    @GetMapping("/findProduct/{productId}")
    public ProductResource restGet(@PathVariable String productId) {
        return service.findProduct(Integer.valueOf(productId));
    }

    @GetMapping("/add")
    public ProductResource addProduct() {
        return service.addProduct();
    }


}
