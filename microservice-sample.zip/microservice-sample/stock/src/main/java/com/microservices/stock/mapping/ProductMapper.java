package com.microservices.stock.mapping;

import com.microservices.stock.entity.Product;
import com.microservices.stock.resource.ProductResource;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProductMapper extends IEntityMapper<ProductResource, Product> {
    //Describe pergh project entrymapper ,citymapper ,educationMapper
}
