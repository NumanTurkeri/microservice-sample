package com.microservices.stock.repository;

import com.microservices.stock.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Integer> {
    public Product findProductByProductId(int productId);
}
