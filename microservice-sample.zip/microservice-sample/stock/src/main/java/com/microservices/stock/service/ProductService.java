package com.microservices.stock.service;

import com.microservices.stock.entity.Product;
import com.microservices.stock.mapping.ProductMapper;
import com.microservices.stock.repository.ProductRepository;
import com.microservices.stock.resource.ProductResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    @Autowired
    ProductRepository repository;
    @Autowired
    ProductMapper mapper;

    @Cacheable("books")
    public ProductResource findProduct(int productId) {
        return mapper.toResource(repository.findProductByProductId(productId));
    }

    int index;

    public ProductResource addProduct() {
        Product product = new Product();
        product.setProductName("Test urun " + index++);
        product.setCount(index++);
        return mapper.toResource(repository.save(product));
    }
}
