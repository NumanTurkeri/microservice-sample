package com.microservices.stock.resource;

import java.io.Serializable;

public class ProductResource implements Serializable {
    public int productId;
    public String productName;
    public int count;
}
